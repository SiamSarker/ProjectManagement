# Data_SenderReceiver
This is a java app for my OS Project.
* Can send data & receive data through ip.
* Multiple Client can be connected to one Server.
* Server & Client both can communicate.
### Status
```
Now Working in Chatting & Multi-Client Management.
```
