public interface IEmployee {
    double CalculateSalary();
    void ShowDetails();
    int GetJobDurationMonth();
}
